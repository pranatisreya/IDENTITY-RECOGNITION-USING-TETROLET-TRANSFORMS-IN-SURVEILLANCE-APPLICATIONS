import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function SecurityPage() {
  const { UserName } = useParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [leaveApplications, setLeaveApplications] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState(null);
  const selectedApplicationRef = useRef(null);

  const [securityInfo, setSecurityInfo] = useState({
    UserName: '',
    Password: '',
    Email: '',
    PhoneNumber: '',
  });

  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const openCamera = () => {
    navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    });
  };

  const stopCamera = () => {
    const stream = videoRef.current?.srcObject;
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const captureImageAndSend = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;

    if (!canvas || !video) {
        alert("❌ Camera not initialized properly.");
        return;
    }

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            alert("❌ Could not generate image from video.");
            return;
        }

        const selectedApp = selectedApplicationRef.current;

        if (!selectedApp || !selectedApp.rollNo) {
            alert("❌ No roll number found. Cannot continue.");
            return;
        }

        const formData = new FormData();
        formData.append('rollNo', selectedApp.rollNo);
        formData.append('image', blob, `${selectedApp.rollNo}_face.jpg`);

        try {
            const response = await axios.post('http://localhost:5000/verify_face', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            console.log("✅ Server response:", response.data);

            const match = response.data.match;
            const newStatus = match ? 'Yes' : 'Did not leave';

            await handleOutTimeRecord(selectedApp, newStatus);
            alert(match ? '✅ Face matched!' : '❌ Face not matched!');
        } catch (error) {
            console.error('❌ Error sending image:', error);
            alert(`🚫 Error verifying face: ${error.response?.data?.error || error.message}`);
        } finally {
            setShowModal(false);
            stopCamera();
        }
    }, 'image/jpeg', 0.95);  // 0.95 is the quality for JPEG
};

  const openModal = (application) => {
    setSelectedApplication(application);
    selectedApplicationRef.current = application;
    setShowModal(true);
    setTimeout(() => {
      openCamera();
    }, 500);
  };

  const fetchSecurityDetails = async () => {
    try {
      const response = await axios.get(`/SecurityPage/${UserName}`);
      setSecurityInfo(response.data);
    } catch (error) {
      console.error('Error fetching Security details:', error);
      setError('An error occurred while fetching Security details.');
    } finally {
      setLoading(false);
    }
  };

  const fetchLeaveApplications = async () => {
    try {
      const response = await axios.get(`/SecurityLeave/${UserName}`);
      setLeaveApplications(response.data.leaveApplications);
    } catch (error) {
      console.error('Error fetching leave applications:', error);
      setError('An error occurred while fetching leave applications.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSecurityDetails();
    fetchLeaveApplications();
  }, [UserName]);

  const handleOutTimeRecord = async (application, status) => {
    try {
      const currentOutTime =
        status === 'Yes'
          ? new Date().toLocaleString('en-IN', {
              timeZone: 'Asia/Kolkata',
              hour: 'numeric',
              minute: 'numeric',
              second: 'numeric',
              weekday: 'short',
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            })
          : 'Did not leave';

      const data = {
        status,
        LeaveDetails: {
          rollNo: application.rollNo,
          reason: application.reason,
          date: application.date,
          timeSlot: application.timeSlot,
        },
      };

      await axios.put(`/SecurityLeave/${application.rollNo}`, data);

      setLeaveApplications((prevApplications) =>
        prevApplications.map((prevApp) =>
          prevApp.rollNo === application.rollNo &&
          prevApp.date === application.date &&
          prevApp.reason === application.reason &&
          prevApp.timeSlot === application.timeSlot
            ? { ...prevApp, outTime: currentOutTime }
            : prevApp
        )
      );
    } catch (error) {
      console.error('Error updating out time:', error);
    }
  };

  const styles = {
    container: {
      maxWidth: '900px',
      margin: '0 auto',
      padding: '20px',
      border: '1px solid #ccc',
      borderRadius: '5px',
      boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
    },
    heading: {
      textAlign: 'center',
      marginBottom: '20px',
      color: 'rgb(160,107,20)',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    th: {
      border: '1px solid #000',
      padding: '8px',
      backgroundColor: '#fff',
      color: '#ad1f21',
    },
    td: {
      border: '1px solid #000',
      padding: '8px',
    },
    button: {
      padding: '2px 10px',
      margin: '2px',
      borderRadius: '5px',
      fontSize: '14px',
      border: '1px solid #999',
      cursor: 'pointer',
    },
  };

  return (
    <>
      <div style={styles.container}>
        <h2 style={styles.heading}>Security Information</h2>
        <ul style={{ paddingLeft: '0' }}>
          {Object.entries(securityInfo).map(([key, value], index) => (
            <li
              key={key}
              style={{
                listStyleType: 'none',
                marginBottom: '10px',
                color: index % 2 === 0 ? '#ad1f21' : 'rgb(160,107,20)',
              }}
            >
              <strong>{key}:</strong> {value || 'N/A'}
            </li>
          ))}
        </ul>
      </div>

      <br />

      <div style={styles.container}>
        <h2 style={styles.heading}>Leave Applications</h2>

        {showModal && (
          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <h3>Face Verification</h3>
            <p>
              Verifying for: <strong>{selectedApplication?.rollNo}</strong>
            </p>
            <video ref={videoRef} width="256" height="256" style={{ border: '1px solid #ccc' }} />
            <br />
            <canvas ref={canvasRef} width="256" height="256" style={{ display: 'none' }} />
            <br />
            <button onClick={captureImageAndSend} style={styles.button}>
              📷 Capture & Verify
            </button>
            <button onClick={stopCamera} style={{ ...styles.button, color: 'red' }}>
              ❌ Close
            </button>
          </div>
        )}

        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p>Error: {error}</p>
        ) : leaveApplications.length > 0 ? (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Index</th>
                <th style={styles.th}>Roll No.</th>
                <th style={styles.th}>Reason</th>
                <th style={styles.th}>Date</th>
                <th style={styles.th}>Time-Slot</th>
                <th style={styles.th}>Out-Time</th>
                <th style={styles.th}>Mark as Out</th>
              </tr>
            </thead>
            <tbody>
              {leaveApplications.map((application, index) => (
                <tr key={application._id}>
                  <td style={styles.td}>{index + 1}</td>
                  <td style={{ ...styles.td, color: 'rgb(160,107,20)' }}>{application.rollNo}</td>
                  <td style={styles.td}>{application.reason}</td>
                  <td style={styles.td}>{application.date}</td>
                  <td style={styles.td}>{application.timeSlot}</td>
                  <td style={styles.td}>{application.outTime}</td>
                  <td style={styles.td}>
                    {application.outTime === 'N/A' && (
                      <>
                        <button
                          style={{ ...styles.button, color: 'green' }}
                          onClick={() => openModal(application)}
                        >
                          📷 Camera
                        </button>
                        <button
                          style={{ ...styles.button, color: 'red' }}
                          onClick={() => handleOutTimeRecord(application, 'Did not leave')}
                        >
                          ❌ No
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No leave applications found.</p>
        )}
      </div>
    </>
  );
}

export default SecurityPage;

// import React, { useState, useEffect, useRef } from 'react';
// import axios from 'axios';
// import { useParams } from 'react-router-dom';

// function SecurityPage() {
//   const { UserName } = useParams();

//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [leaveApplications, setLeaveApplications] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [selectedApplication, setSelectedApplication] = useState(null); // ✅ Added
//   const selectedApplicationRef = useRef(null);

//   const [securityInfo, setSecurityInfo] = useState({
//     UserName: '',
//     Password: '',
//     Email: '',
//     PhoneNumber: '',
//   });

//   const videoRef = useRef(null);
//   const canvasRef = useRef(null);

//   const openCamera = () => {
//     navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
//       videoRef.current.srcObject = stream;
//       videoRef.current.play();
//     });
//   };

//   const stopCamera = () => {
//     const stream = videoRef.current?.srcObject;
//     if (stream) {
//       stream.getTracks().forEach((track) => track.stop());
//     }
//   };

//   const captureImageAndSend = async () => {
//   const canvas = canvasRef.current;
//   const video = videoRef.current;
//   const context = canvas.getContext('2d');

//   context.drawImage(video, 0, 0, 256, 256);

//   canvas.toBlob(async (blob) => {
//     const selectedApp = selectedApplicationRef.current;

//     if (!selectedApp || !selectedApp.rollNo) {
//       alert("❌ No roll number found. Cannot continue.");
//       return;
//     }

//     const formData = new FormData();
//     formData.append('roll_no', selectedApp.rollNo);
//     formData.append('image', blob, 'face.jpg');

//     // Debug FormData
//     for (let [key, val] of formData.entries()) {
//       console.log(`${key}:`, val);
//     }

//     try {
//       const response = await axios.post('http://127.0.0.1:5000/verify_face', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         }
//       });

//       console.log("✅ Server response:", response.data);
//       const match = response.data.match;
//       const newStatus = match ? 'Yes' : 'Did not leave';

//       await handleOutTimeRecord(selectedApp, newStatus);
//       alert(match ? '✅ Face matched!' : '❌ Face not matched!');
//     } catch (error) {
//       console.error('❌ Error sending image:', error);
//       alert('🚫 Error verifying face. Backend rejected the request.');
//     } finally {
//       setShowModal(false);
//       stopCamera();
//     }
//   }, 'image/jpeg');
// };


//   const openModal = (application) => {
//     setSelectedApplication(application);
//     selectedApplicationRef.current = application;
//     setShowModal(true);
//     setTimeout(() => {
//       openCamera();
//     }, 500);
//   };

//   const fetchSecurityDetails = async () => {
//     try {
//       const response = await axios.get(`/SecurityPage/${UserName}`);
//       setSecurityInfo(response.data);
//     } catch (error) {
//       console.error('Error fetching Security details:', error);
//       setError('An error occurred while fetching Security details.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchLeaveApplications = async () => {
//     try {
//       const response = await axios.get(`/SecurityLeave/${UserName}`);
//       setLeaveApplications(response.data.leaveApplications);
//     } catch (error) {
//       console.error('Error fetching leave applications:', error);
//       setError('An error occurred while fetching leave applications.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchSecurityDetails();
//     fetchLeaveApplications();
//   }, [UserName]);

//   const handleOutTimeRecord = async (application, status) => {
//     try {
//       const currentOutTime =
//         status === 'Yes'
//           ? new Date().toLocaleString('en-IN', {
//               timeZone: 'Asia/Kolkata',
//               hour: 'numeric',
//               minute: 'numeric',
//               second: 'numeric',
//               weekday: 'short',
//               day: 'numeric',
//               month: 'short',
//               year: 'numeric',
//             })
//           : 'Did not leave';

//       const data = {
//         status,
//         LeaveDetails: {
//           rollNo: application.rollNo,
//           reason: application.reason,
//           date: application.date,
//           timeSlot: application.timeSlot,
//         },
//       };

//       await axios.put(`/SecurityLeave/${application.rollNo}`, data);

//       setLeaveApplications((prevApplications) =>
//         prevApplications.map((prevApp) =>
//           prevApp.rollNo === application.rollNo &&
//           prevApp.date === application.date &&
//           prevApp.reason === application.reason &&
//           prevApp.timeSlot === application.timeSlot
//             ? { ...prevApp, outTime: currentOutTime }
//             : prevApp
//         )
//       );
//     } catch (error) {
//       console.error('Error updating out time:', error);
//     }
//   };

//   const styles = {
//     container: {
//       maxWidth: '900px',
//       margin: '0 auto',
//       padding: '20px',
//       border: '1px solid #ccc',
//       borderRadius: '5px',
//       boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
//     },
//     heading: {
//       textAlign: 'center',
//       marginBottom: '20px',
//       color: 'rgb(160,107,20)',
//     },
//     table: {
//       width: '100%',
//       borderCollapse: 'collapse',
//     },
//     th: {
//       border: '1px solid #000',
//       padding: '8px',
//       backgroundColor: '#fff',
//       color: '#ad1f21',
//     },
//     td: {
//       border: '1px solid #000',
//       padding: '8px',
//     },
//     button: {
//       padding: '2px 10px',
//       margin: '2px',
//       borderRadius: '5px',
//       fontSize: '14px',
//       border: '1px solid #999',
//       cursor: 'pointer',
//     },
//   };

//   return (
//     <>
//       <div style={styles.container}>
//         <h2 style={styles.heading}>Security Information</h2>
//         <ul style={{ paddingLeft: '0' }}>
//           {Object.entries(securityInfo).map(([key, value], index) => (
//             <li
//               key={key}
//               style={{
//                 listStyleType: 'none',
//                 marginBottom: '10px',
//                 color: index % 2 === 0 ? '#ad1f21' : 'rgb(160,107,20)',
//               }}
//             >
//               <strong>{key}:</strong> {value || 'N/A'}
//             </li>
//           ))}
//         </ul>
//       </div>

//       <br />

//       <div style={styles.container}>
//         <h2 style={styles.heading}>Leave Applications</h2>

//         {showModal && (
//           <div style={{ textAlign: 'center', marginTop: '20px' }}>
//             <h3>Face Verification</h3>
//             <p>
//               Verifying for: <strong>{selectedApplication?.rollNo}</strong>
//             </p>
//             <video ref={videoRef} width="256" height="256" style={{ border: '1px solid #ccc' }} />
//             <br />
//             <canvas ref={canvasRef} width="256" height="256" style={{ display: 'none' }} />
//             <br />
//             <button onClick={captureImageAndSend} style={styles.button}>
//               📷 Capture & Verify
//             </button>
//             <button onClick={stopCamera} style={{ ...styles.button, color: 'red' }}>
//               ❌ Close
//             </button>
//           </div>
//         )}

//         {loading ? (
//           <p>Loading...</p>
//         ) : error ? (
//           <p>Error: {error}</p>
//         ) : leaveApplications.length > 0 ? (
//           <table style={styles.table}>
//             <thead>
//               <tr>
//                 <th style={styles.th}>Index</th>
//                 <th style={styles.th}>Roll No.</th>
//                 <th style={styles.th}>Reason</th>
//                 <th style={styles.th}>Date</th>
//                 <th style={styles.th}>Time-Slot</th>
//                 <th style={styles.th}>Out-Time</th>
//                 <th style={styles.th}>Mark as Out</th>
//               </tr>
//             </thead>
//             <tbody>
//               {leaveApplications.map((application, index) => (
//                 <tr key={application._id}>
//                   <td style={styles.td}>{index + 1}</td>
//                   <td style={{ ...styles.td, color: 'rgb(160,107,20)' }}>{application.rollNo}</td>
//                   <td style={styles.td}>{application.reason}</td>
//                   <td style={styles.td}>{application.date}</td>
//                   <td style={styles.td}>{application.timeSlot}</td>
//                   <td style={styles.td}>{application.outTime}</td>
//                   <td style={styles.td}>
//                     {application.outTime === 'N/A' && (
//                       <>
//                         <button
//                           style={{ ...styles.button, color: 'green' }}
//                           onClick={() => openModal(application)}
//                         >
//                           📷 Camera
//                         </button>
//                         <button
//                           style={{ ...styles.button, color: 'red' }}
//                           onClick={() => handleOutTimeRecord(application, 'Did not leave')}
//                         >
//                           ❌ No
//                         </button>
//                       </>
//                     )}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         ) : (
//           <p>No leave applications found.</p>
//         )}
//       </div>
//     </>
//   );
// }

// export default SecurityPage;
