from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import numpy as np
import cv2
from PIL import Image
from transformations import extract_face, generate_feature_maps, compute_similarity_scores, is_match

app = Flask(__name__)

# Allow React frontend running on localhost:3000 to access this backend
CORS(app, resources={r"/verify_face": {"origins": "http://localhost:3000"}})

STORAGE_FOLDER = "storage"  # Folder with rollNo.jpg images

@app.route("/verify_face", methods=["POST"])
def verify_face():
    if 'image' not in request.files or 'rollNo' not in request.form:
        return jsonify({"error": "Missing image file or roll number"}), 400

    file = request.files['image']
    rollNo = request.form['rollNo']

    print("Received rollNo:", rollNo)
    print("Received file:", file.filename)

    try:
        # Save uploaded file temporarily
        uploaded_image_path = f"temp_{rollNo}.jpg"
        file.save(uploaded_image_path)

        stored_image_path = os.path.join(STORAGE_FOLDER, f"{rollNo}.jpg")

        if not os.path.exists(stored_image_path):
            return jsonify({"match": "No", "reason": "No stored image for this roll number"}), 404

        # Extract faces
        face1 = extract_face(uploaded_image_path)
        face2 = extract_face(stored_image_path)

        if face1 is None or face2 is None:
            return jsonify({"match": "No", "reason": "Face not detected"}), 400

        # Compute similarity
        f1_maps = generate_feature_maps(face1)
        f2_maps = generate_feature_maps(face2)
        similarity_scores = compute_similarity_scores(f1_maps, f2_maps)
        matched = is_match(similarity_scores)

        os.remove(uploaded_image_path)  # Clean up

        return jsonify({"match": "Yes" if matched else "No"})

    except Exception as e:
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)