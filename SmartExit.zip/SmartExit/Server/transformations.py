# transformations.py
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim
import mediapipe as mp

mp_face_detection = mp.solutions.face_detection

def extract_face(image_path_or_array):
    if isinstance(image_path_or_array, str):
        image = Image.open(image_path_or_array).convert("RGB")
        image = np.array(image)
    else:
        image = image_path_or_array

    with mp_face_detection.FaceDetection(min_detection_confidence=0.5) as face_detector:
        results = face_detector.process(image)

        if results.detections:
            for detection in results.detections:
                bboxC = detection.location_data.relative_bounding_box
                h, w, _ = image.shape
                x, y, w_box, h_box = (
                    int(bboxC.xmin * w), int(bboxC.ymin * h),
                    int(bboxC.width * w), int(bboxC.height * h)
                )
                face = image[y:y+h_box, x:x+w_box]
                face_gray = np.dot(face[..., :3], [0.2989, 0.5870, 0.1140])
                face_gray = np.clip(face_gray, 0, 255).astype(np.uint8)
                face_gray = np.array(Image.fromarray(face_gray).resize((256, 256)))
                return face_gray
    return None





import numpy as np


# Initialize variables
sqrt2 = np.sqrt(4)
results=[]

# Haar wavelet transform on a 4x4 block
def I_transform(image):
    rows, cols = image.shape
    transformed_img = np.copy(image)

    for i in range(0, rows, 4):
        for j in range(0, cols, 4):
            # Extract the 4x4 block
            block = image[i:i+4, j:j+4]

            # Initialize T-shape transformed block
            T_shape = np.zeros_like(block)

            block = block.astype(np.float64)
            T_shape = T_shape.astype(np.float64)

            # Apply the Haar transform as described
            # Averaging (once)
            T_shape[0, 0] = (block[0, 0] + block[0,1] + block[0,2] + block[0,3]) / sqrt2
            T_shape[0,1] = (block[0, 0] - block[0,1] + block[0,2] - block[0,3]) / sqrt2
            T_shape[0,2] = (block[0, 0] + block[0,1] - block[0,2] - block[0,3]) / sqrt2
            T_shape[0,3] = (block[0, 0] - block[0,1] - block[0,2] + block[0,3]) / sqrt2

            T_shape[1,0] = (block[1,0] + block[1,1] + block[1, 2] + block[1, 3]) / sqrt2
            T_shape[1,1] = (block[1,0] - block[1,1] + block[1, 2] - block[1, 3]) / sqrt2
            T_shape[1,2] = (block[1,0] + block[1,1] - block[1, 2] - block[1, 3]) / sqrt2
            T_shape[1,3] = (block[1,0] - block[1,1] - block[1, 2] + block[1, 3]) / sqrt2

            T_shape[2,0]= (block[2,0] + block[2, 1] + block[2,2] + block[2,3]) / sqrt2
            T_shape[2,1] = (block[2,0] - block[2, 1] + block[2,2] - block[2,3]) / sqrt2
            T_shape[2,2] = (block[2,0] + block[2, 1] - block[2,2] - block[2,3]) / sqrt2
            T_shape[2,3] = (block[2,0] - block[2, 1] - block[2,2] + block[2,3]) / sqrt2

            T_shape[3, 0] = (block[3, 0] + block[3, 1] + block[3, 2] + block[3,3]) / sqrt2
            T_shape[3, 1] = (block[3, 0] - block[3,1] + block[3, 2] - block[3,3]) / sqrt2
            T_shape[3, 2] = (block[3, 0] + block[3,1] - block[3, 2] - block[3,3]) / sqrt2
            T_shape[3,3] = (block[3, 0] - block[3,1] - block[3, 2] + block[3,3]) / sqrt2

            block = T_shape

            # Averaging (vertical)
            T_shape[0, 0] = (block[0, 0] + block[1, 0] + block[2, 0] + block[3, 0]) / sqrt2
            T_shape[1, 0] = (block[0, 0] - block[1, 0] + block[2, 0] - block[3, 0]) / sqrt2
            T_shape[2, 0] = (block[0, 0] + block[1, 0] - block[2, 0] - block[3, 0]) / sqrt2
            T_shape[3, 0] = (block[0, 0] - block[1, 0] - block[2, 0] + block[3, 0]) / sqrt2

            T_shape[0, 1] = (block[0, 1] + block[1, 1] + block[2, 1] + block[3, 1]) / sqrt2
            T_shape[1, 1] = (block[0, 1] - block[1, 1] + block[2, 1] - block[3, 1]) / sqrt2
            T_shape[2, 1] = (block[0, 1] + block[1, 1] - block[2, 1] - block[3, 1]) / sqrt2
            T_shape[3, 1] = (block[0, 1] - block[1, 1] - block[2, 1] + block[3, 1]) / sqrt2

            T_shape[0, 2] = (block[0, 2] + block[1, 2] + block[2, 2] + block[3, 2]) / sqrt2
            T_shape[1, 2] = (block[0, 2] - block[1, 2] + block[2, 2] - block[3, 2]) / sqrt2
            T_shape[2, 2] = (block[0, 2] + block[1, 2] - block[2, 2] - block[3, 2]) / sqrt2
            T_shape[3, 2] = (block[0, 2] - block[1, 2] - block[2, 2] + block[3, 2]) / sqrt2

            T_shape[0, 3] = (block[0, 3] + block[1, 3] + block[2, 3] + block[3, 3]) / sqrt2
            T_shape[1, 3] = (block[0, 3] - block[1, 3] + block[2, 3] - block[3, 3]) / sqrt2
            T_shape[2, 3] = (block[0, 3] + block[1, 3] - block[2, 3] - block[3, 3]) / sqrt2
            T_shape[3, 3] = (block[0, 3] - block[1, 3] - block[2, 3] + block[3, 3]) / sqrt2

            # Check for NaN or Inf and replace with a finite number
            if np.any(np.isnan(T_shape)) or np.any(np.isinf(T_shape)):
                T_shape = np.nan_to_num(T_shape, nan=0.0, posinf=1e10, neginf=-1e10)

            transformed_img[i:i+4, j:j+4] = T_shape

    return transformed_img


import numpy as np


# Initialize variables
sqrt2 = np.sqrt(4)

results=[]

# Haar wavelet transform on a 4x4 block
def L_transform(image):
    rows, cols = image.shape
    transformed_img = np.copy(image)

    for i in range(0, rows, 4):
        for j in range(0, cols, 4):
            # Extract the 4x4 block
            block = image[i:i+4, j:j+4]

            # Initialize T-shape transformed block
            T_shape = np.zeros_like(block)

            block = block.astype(np.float64)
            T_shape = T_shape.astype(np.float64)

            # Apply the Haar transform as described
            # Averaging (once)
            T_shape[0, 0] = (block[0, 0] + block[1, 0] + block[2,0] + block[2,1]) / sqrt2
            T_shape[1, 0] = (block[0, 0] - block[1,0] + block[2,0] - block[2,1]) / sqrt2
            T_shape[2, 0] = (block[0, 0] + block[1,0] - block[2,0] - block[2,1]) / sqrt2
            T_shape[2, 1] = (block[0, 0] - block[1,0] - block[2,0] + block[2,1]) / sqrt2

            T_shape[0,1] = (block[0, 1] - block[0,2] + block[0, 3] - block[1, 1]) / sqrt2
            T_shape[0,2] = (block[0, 1] + block[0,2] - block[0, 3] - block[1, 1]) / sqrt2
            T_shape[0, 3] = (block[0, 1] + block[0,2] + block[0, 3] + block[1, 1]) / sqrt2
            T_shape[1, 1] = (block[0, 1] - block[0,2] - block[0, 3] + block[1, 1]) / sqrt2

            T_shape[3, 0] = (block[3, 0] + block[3, 1] + block[3, 2] + block[2, 2]) / sqrt2
            T_shape[3, 1] = (block[3, 0] - block[3,1] + block[3, 2] - block[2, 2]) / sqrt2
            T_shape[3, 2] = (block[3, 0] + block[3,1] - block[3, 2] - block[2, 2]) / sqrt2
            T_shape[2, 2] = (block[3, 0] - block[3,1] - block[3, 2] + block[2, 2]) / sqrt2

            T_shape[1, 3] = (block[1,3] + block[2, 3] + block[3, 3] + block[1, 2]) / sqrt2
            T_shape[2, 3] = (block[1,3] - block[2, 3] + block[3, 3] - block[1, 2]) / sqrt2
            T_shape[3, 3] = (block[1,3] + block[2, 3] - block[3, 3] - block[1, 2]) / sqrt2
            T_shape[1, 2] = (block[1,3] - block[2, 3] - block[3, 3] + block[1, 2]) / sqrt2

            block = T_shape

             # Averaging (second)

            T_shape[0, 1] = (block[0,1] + block[1,1] + block[2,1] + block[0,0]) / sqrt2
            T_shape[1, 1] = (block[0,1] - block[1,1] + block[2,1] - block[0,0]) / sqrt2
            T_shape[2, 1] = (block[0,1] + block[1,1] - block[2,1] - block[0,0]) / sqrt2
            T_shape[0, 0] = (block[0,1] - block[1,1] - block[2,1] + block[0,0]) / sqrt2

            T_shape[0, 2] = (block[0, 2] + block[1, 2] + block[2, 2] + block[0,3]) / sqrt2
            T_shape[1, 2] = (block[0, 2] - block[1, 2] + block[2, 2] - block[0,3]) / sqrt2
            T_shape[2, 2] = (block[0, 2] + block[1, 2] - block[2, 2] - block[0,3]) / sqrt2
            T_shape[0,3] = (block[0, 2] - block[1, 2] - block[2, 2] + block[0,3]) / sqrt2


            T_shape[1, 0] = (block[1, 0] + block[2, 0] + block[3, 0] + block[3, 1]) / sqrt2
            T_shape[2, 0] = (block[1, 0] - block[2, 0] + block[3, 0] - block[3, 1]) / sqrt2
            T_shape[3, 0] = (block[1, 0] + block[2, 0] - block[3, 0] - block[3, 1]) / sqrt2
            T_shape[3, 1] = (block[1, 0] - block[2, 0] - block[3, 0] + block[3, 1]) / sqrt2

            T_shape[1,3] = (block[1,3] + block[2,3] + block[3,3] + block[3,2]) / sqrt2
            T_shape[2,3] = (block[1,3] - block[2,3] + block[3,3] - block[3,2]) / sqrt2
            T_shape[3,3] = (block[1,3] + block[2,3] - block[3,3] - block[3,2]) / sqrt2
            T_shape[3,2] = (block[1,3] - block[2,3] - block[3,3] + block[3,2]) / sqrt2

            # # Calculate L1 norm for the current block
            # l1_norm = np.sum(np.abs(T_shape))  # L1 norm calculation
            # results.append((T_shape, l1_norm))

            # Check for NaN or Inf and replace with a finite number
            if np.any(np.isnan(T_shape)) or np.any(np.isinf(T_shape)):
                T_shape = np.nan_to_num(T_shape, nan=0.0, posinf=1e10, neginf=-1e10)


            transformed_img[i:i+4, j:j+4] = T_shape


    return transformed_img

import numpy as np



# Initialize variables
sqrt2 = np.sqrt(4)
results=[]

# Haar wavelet transform on a 4x4 block
def T_transform(image):
    rows, cols = image.shape
    transformed_img = np.copy(image)

    for i in range(0, rows, 4):
        for j in range(0, cols, 4):
            # Extract the 4x4 block
            block = image[i:i+4, j:j+4]

            # Initialize T-shape transformed block
            T_shape = np.zeros_like(block)

            block = block.astype(np.float64)
            T_shape = T_shape.astype(np.float64)

            # Apply the Haar transform as described
            # Averaging (once)
            T_shape[0, 0] = (block[0, 0] + block[0, 1] + block[0, 2] + block[1, 1]) / sqrt2
            T_shape[0, 1] = (block[0, 0] - block[0, 1] + block[0, 2] - block[1, 1]) / sqrt2
            T_shape[0, 2] = (block[0, 0] + block[0, 1] - block[0, 2] - block[1, 1]) / sqrt2
            T_shape[1, 1] = (block[0, 0] - block[0, 1] - block[0, 2] + block[1, 1]) / sqrt2

            T_shape[0, 3] = (block[0, 3] + block[1, 3] + block[2, 3] + block[1, 2]) / sqrt2
            T_shape[1, 3] = (block[0, 3] - block[1, 3] + block[2, 3] - block[1, 2]) / sqrt2
            T_shape[2, 3] = (block[0, 3] + block[1, 3] - block[2, 3] - block[1, 2]) / sqrt2
            T_shape[1, 2] = (block[0, 3] - block[1, 3] - block[2, 3] + block[1, 2]) / sqrt2

            T_shape[1, 0] = (block[1, 0] + block[2, 0] + block[3, 0] + block[2, 1]) / sqrt2
            T_shape[2, 0] = (block[1, 0] - block[2, 0] + block[3, 0] - block[2, 1]) / sqrt2
            T_shape[3, 0] = (block[1, 0] + block[2, 0] - block[3, 0] - block[2, 1]) / sqrt2
            T_shape[2, 1] = (block[1, 0] - block[2, 0] - block[3, 0] + block[2, 1]) / sqrt2

            T_shape[3, 1] = (block[3, 1] + block[3, 2] + block[3, 3] + block[2, 2]) / sqrt2
            T_shape[3, 2] = (block[3, 1] - block[3, 2] + block[3, 3] - block[2, 2]) / sqrt2
            T_shape[3, 3] = (block[3, 1] + block[3, 2] - block[3, 3] - block[2, 2]) / sqrt2
            T_shape[2, 2] = (block[3, 1] - block[3, 2] - block[3, 3] + block[2, 2]) / sqrt2

            block = T_shape
            # Averaging (second)

            T_shape[0, 0] = (block[0, 0] + block[1, 0] + block[2, 0] + block[1, 1]) / sqrt2
            T_shape[1, 0] = (block[0, 0] - block[1, 0] + block[2, 0] - block[1, 1]) / sqrt2
            T_shape[2, 0] = (block[0, 0] + block[1, 0] - block[2, 0] - block[1, 1]) / sqrt2
            T_shape[1, 1] = (block[0, 0] - block[1, 0] - block[2, 0] + block[1, 1]) / sqrt2

            T_shape[0, 1] = (block[0, 1] - block[0, 2] + block[0, 3] - block[1, 2]) / sqrt2
            T_shape[0, 2] = (block[0, 1] + block[0, 2] - block[0, 3] - block[1, 2]) / sqrt2
            T_shape[0, 3] = (block[0, 1] + block[0, 2] + block[0, 3] + block[1, 2]) / sqrt2
            T_shape[1, 2] = (block[0, 1] - block[0, 2] - block[0, 3] + block[1, 2]) / sqrt2

            T_shape[3, 0] = (block[3, 0] + block[3, 1] + block[3, 2] + block[2, 1]) / sqrt2
            T_shape[3, 1] = (block[3, 0] - block[3, 1] + block[3, 2] - block[2, 1]) / sqrt2
            T_shape[3, 2] = (block[3, 0] + block[3, 1] - block[3, 2] - block[2, 1]) / sqrt2
            T_shape[2, 1] = (block[3, 0] - block[3, 1] - block[3, 2] + block[2, 1]) / sqrt2

            T_shape[1, 3] = (block[1, 3] + block[2, 3] + block[3, 3] + block[2, 2]) / sqrt2
            T_shape[2, 3] = (block[1, 3] - block[2, 3] + block[3, 3] - block[2, 2]) / sqrt2
            T_shape[3, 3] = (block[1, 3] + block[2, 3] - block[3, 3] - block[2, 2]) / sqrt2
            T_shape[2, 2] = (block[1, 3] - block[2, 3] - block[3, 3] + block[2, 2]) / sqrt2


            # # Calculate L1 norm for the current block
            # l1_norm = np.sum(np.abs(T_shape))  # L1 norm calculation
            # results.append((T_shape, l1_norm))


            # Check for NaN or Inf and replace with a finite number
            if np.any(np.isnan(T_shape)) or np.any(np.isinf(T_shape)):
                T_shape = np.nan_to_num(T_shape, nan=0.0, posinf=1e10, neginf=-1e10)



            transformed_img[i:i+4, j:j+4] = T_shape

    return transformed_img


import numpy as np


# Initialize variables
sqrt2 = np.sqrt(4)
results = []

# Haar wavelet transform on a 4x4 block
def o_transformation(image):
    rows, cols = image.shape
    transformed_img = np.copy(image)  # Use a higher precision data type

    for i in range(0, rows, 4):
        for j in range(0, cols, 4):
            # Extract the 4x4 block
            block = image[i:i+4, j:j+4]

            # Initialize T-shape transformed block with higher precision
            T_shape = np.zeros_like(block)  # Use np.float128
            block = block.astype(np.float64)
            T_shape = T_shape.astype(np.float64)

            # Apply the Haar transform as described
            T_shape[0, 0] = (block[0, 0] + block[0,1] + block[1,0] + block[1,1]) / sqrt2
            T_shape[0,1] = (block[0, 0] - block[0,1] + block[1,0] - block[1,1]) / sqrt2
            T_shape[1,0] = (block[0,0] + block[0,1] - block[1, 0] - block[1, 1]) / sqrt2
            T_shape[1,1] = (block[0,0] - block[0,1] - block[1, 0] + block[1, 1]) / sqrt2

            T_shape[0,2] = (block[0, 2] + block[0,3] + block[1,2] + block[1,3]) / sqrt2
            T_shape[0,3] = (block[0, 2] - block[0,3] - block[1,2] + block[1,3]) / sqrt2
            T_shape[1,2] = (block[0,2] + block[0,3] - block[1, 2] - block[1,3]) / sqrt2
            T_shape[1,3] = (block[0,2] - block[0,3] - block[1, 2] + block[1, 3]) / sqrt2

            T_shape[2,0]= (block[2,0] + block[2, 1] + block[3,0] + block[3,1]) / sqrt2
            T_shape[2,1] = (block[2,0] - block[2, 1] + block[3,0] - block[3,1]) / sqrt2
            T_shape[3, 0] = (block[2, 0] + block[2, 1] + block[3,0] + block[3,1]) / sqrt2
            T_shape[3, 1] = (block[2, 0] - block[2,1] + block[3,0 ] - block[3,1]) / sqrt2

            T_shape[2,2] = (block[2,2] + block[2, 3] + block[3,2] + block[3,3]) / sqrt2
            T_shape[2,3] = (block[2,2] - block[2, 2] - block[3,2] + block[3,3]) / sqrt2
            T_shape[3,2] = (block[2,2] + block[2,3] - block[3, 2] - block[3,3]) / sqrt2
            T_shape[3,3] = (block[2,2] - block[2,3] - block[3, 2] + block[3,3]) / sqrt2

            # Replace NaN and infinity values with finite numbers
            if np.any(np.isnan(T_shape)) or np.any(np.isinf(T_shape)):
                T_shape = np.nan_to_num(T_shape)

            transformed_img[i:i+4, j:j+4] = T_shape

    return transformed_img




def generate_feature_maps(image):
    return {
        "Original": image,
        "O Transform": o_transformation(image),
        "L Transform": L_transform(image),
        "I Transform": I_transform(image),
        "T Transform": T_transform(image)
    }

def compute_similarity_scores(images1, images2):
    scores = {}
    pairs = [("Original", "Original"), ("O Transform", "O Transform"),
             ("L Transform", "L Transform"), ("I Transform", "I Transform"),
             ("T Transform", "T Transform")]
    for a, b in pairs:
        img1, img2 = images1[a], images2[b]
        if img1.shape != img2.shape:
            img2 = np.array(Image.fromarray(img2).resize(img1.shape[::-1]))
        scores[f"{a} vs {b}"] = ssim(img1, img2)
    return scores

def is_match(similarity_scores):
    thresholds = {
        "Original vs Original": 0.4,
        "O Transform vs O Transform": 0.1,
        "L Transform vs L Transform": 0.5,
        "I Transform vs I Transform": 0.1,
        "T Transform vs T Transform": 0.3
    }
    passed = [pair for pair, score in similarity_scores.items() if score >= thresholds.get(pair, 0.65)]
    return len(passed) >= 4
